            
            let currentSlide = 0;
                const slides = document.querySelectorAll('.slide');
                const totalSlides = slides.length;

                function showSlide(index) {
                    slides[currentSlide].classList.remove('active');
                    currentSlide = (index + totalSlides) % totalSlides;
                    slides[currentSlide].classList.add('active');
                }

                function nextSlide() {
                    showSlide(currentSlide + 1);
                }

                function prevSlide() {
                    showSlide(currentSlide - 1);
                }

                // Set interval to change slides every 5 seconds
                // setInterval(nextSlide, 5000);

//  var modal = document.getElementById("myModal");

//  var btn = document.getElementById("viewDetailBtn");

//  var span = document.getElementsByClassName("close")[0];

//  btn.onclick = function() {
//      modal.style.display = "block";
//  }

//  span.onclick = function() {
//      modal.style.display = "none";
//  }


//  window.onclick = function(event) {
//      if (event.target == modal) {
//          modal.style.display = "none";
//      }
//  }

    // Select all "View Detail" buttons
    const viewDetailBtns = document.querySelectorAll(".viewDetailBtn");

    // Loop through each button
    viewDetailBtns.forEach((btn, index) => {
        // Add click event to each button
        btn.addEventListener('click', function() {
            // Show the corresponding modal
            const modal = btn.nextElementSibling;
            modal.style.display = "block";
        });
    });
    
    // Select all close buttons
    const closeBtns = document.querySelectorAll(".close");
    
    // Loop through each close button
    closeBtns.forEach((span, index) => {
        // Add click event to close the modal
        span.addEventListener('click', function() {
            // Find the closest modal and hide it
            const modal = span.closest('.modal');
            modal.style.display = "none";
        });
    });
    
    // Close the modal when clicking outside of it
    window.addEventListener('click', function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        const buttons = document.querySelectorAll('.accordion-button');
    
        buttons.forEach(button => {
            button.addEventListener('click', function() {
                const content = this.nextElementSibling;
    
                // Toggle the current section
                if (content.style.display === 'block') {
                    content.style.display = 'none';
                } else {
                    // Close all sections
                    document.querySelectorAll('.accordion-content').forEach(item => {
                        item.style.display = 'none';
                    });
    
                    // Open the current section
                    content.style.display = 'block';
                }
            });
        });
    });
    
    